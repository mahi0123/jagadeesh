package com.cg.Plp30;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Plp30Application {

	public static void main(String[] args) {
		SpringApplication.run(Plp30Application.class, args);
	}

}
