package com.cg.Plp30.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.Plp30.dao.RatingDao;
import com.cg.Plp30.entities.ProductRating;

@Service
public class RatingServiceImpl implements RatingService{

	
	@Autowired
	private RatingDao dao;

	@Transactional
	public void setRatingtoProduct(ProductRating rt) {
		dao.save(rt);
	}

	/*@Override
	public ProductRating search(Integer productid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void AvgProductRating(Integer productid, String productname, Integer productRating) {
		// TODO Auto-generated method stub
		
	}*/
	
	
	
	
	
	

}
