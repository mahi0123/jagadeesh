package com.cg.Plp30.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Plp30.entities.ProductRating;
import com.cg.Plp30.service.RatingService;

@RestController
@RequestMapping("")
public class RatingController {
	
	@Autowired RatingService service;
	
	
	//Set rating to product
	@PostMapping(value= {"/setrating"}, consumes= {"application/json","application/xml"})
	public ResponseEntity<String> setRating(@RequestBody ProductRating rt)
	{
		System.out.println("Rating to Product"+rt.getProductname()+"by"+rt.getCustemil());
		service.setRatingtoProduct(rt);
		
		return new ResponseEntity<String>("Product is rated "+rt.getProductRating()+"by"+rt.getCustemil(),HttpStatus.CREATED);
	}
	
	
	/*@GetMapping(value="/{productid}",produces= {"application/json","application/xml"})
	
	public ProductRating search(@PathVariable Integer productid) {
					
		System.out.println("Retriving rating of Product"+productid);
		
		return service.search(productid);
			
	}*/
	

}
