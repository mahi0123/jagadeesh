package com.cg.Plp30.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity 
@Table(name="ratingproducts")
@XmlRootElement
public class ProductRating {

	@Id
	
	
	
	
	@Column(name="custemil",length=20)
	private String custemil;
	@Column(name="productid",length=10)
	private Integer productid;
	
	@Column(name="productname",length=30)
	private String Productname;
	
	@Column(name="productRating",length=3)
	private Integer productRating;
	
	@Column(name="AvgRatingofProduct",length=3)
	private Integer AvgRatingofProduct;

	
	
	public String getCustemil() {
		return custemil;
	}

	public void setCustemil(String custemil) {
		this.custemil = custemil;
	}

	public Integer getProductid() {
		return productid;
	}

	public void setProductid(Integer productid) {
		this.productid = productid;
	}

	public String getProductname() {
		return Productname;
	}

	public void setProductname(String productname) {
		Productname = productname;
	}

	public Integer getProductRating() {
		return productRating;
	}

	public void setProductRating(Integer productRating) {
		this.productRating = productRating;
	}

	public Integer getAvgRatingofProduct() {
		return AvgRatingofProduct;
	}

	public void setAvgRatingofProduct(Integer avgRatingofProduct) {
		AvgRatingofProduct = avgRatingofProduct;
	}
	
	
	
	
}
