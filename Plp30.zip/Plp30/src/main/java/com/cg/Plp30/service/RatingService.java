package com.cg.Plp30.service;

import com.cg.Plp30.entities.ProductRating;

public interface RatingService {
	
	void setRatingtoProduct(ProductRating rt);
	
	//ProductRating search (Integer productid);
	
	//void AvgProductRating(Integer productid,String productname,Integer productRating );
	

}
