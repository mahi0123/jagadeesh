package com.cg.Plp30.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity 
@Table(name="customer")
@XmlRootElement
public class Customer {

	
	@Id
	
	@Column(name="custemil",length=20)
	private String custemil;
	
	@Column(name="custname",length=30)
	private String custname;
	
	

	public String getCustemil() {
		return custemil;
	}

	public void setCustemil(String custemil) {
		this.custemil = custemil;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	
	
	
	
	
}
