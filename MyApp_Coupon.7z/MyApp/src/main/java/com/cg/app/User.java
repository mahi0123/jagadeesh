package com.cg.app;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="gcoupon")
public class User {	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int couponid; 
	@Column(unique=true)
	private String couponcode;
	private java.sql.Date fromDate;
	private java.sql.Date toDate;	
	private String status;
	private double startprice;
	private double endprice;
	private int discount;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User(int couponid, String couponcode, Date fromDate, Date toDate, String status, double startprice,
			double endprice, int discount) {
		super();
		this.couponid = couponid;
		this.couponcode = couponcode;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.status = status;
		this.startprice = startprice;
		this.endprice = endprice;
		this.discount = discount;
	}
	public int getCouponid() {
		return couponid;
	}
	public void setCouponid(int couponid) {
		this.couponid = couponid;
	}
	public String getCouponcode() {
		return couponcode;
	}
	public void setCouponcode(String couponcode) {
		this.couponcode = couponcode;
	}
	public java.sql.Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(java.sql.Date fromDate) {
		this.fromDate = fromDate;
	}
	public java.sql.Date getToDate() {
		return toDate;
	}
	public void setToDate(java.sql.Date toDate) {
		this.toDate = toDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getStartprice() {
		return startprice;
	}
	public void setStartprice(double startprice) {
		this.startprice = startprice;
	}
	public double getEndprice() {
		return endprice;
	}
	public void setEndprice(double endprice) {
		this.endprice = endprice;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	@Override
	public String toString() {
		return "User [couponid=" + couponid + ", couponcode=" + couponcode + ", fromDate=" + fromDate + ", toDate="
				+ toDate + ", status=" + status + ", startprice=" + startprice + ", endprice=" + endprice
				+ ", discount=" + discount + "]";
	}
	
	
	
	
	/*
	@Id
	@Column(length=10)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
	@Column(length=30)
    private final String name;
	@Column(length=30)
    private final String email;

    public User() {
        this.name = "";
        this.email = "";
    }
    
    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public long getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
    
    @Override
    public String toString() {
        return "User{" + "id=" + id + ", name=" + name + ", email=" + email + '}';
    }*/
}
