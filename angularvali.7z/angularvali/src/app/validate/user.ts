export interface Iuser
{

        email: string
        password: string
        contact: string
        question: string
        answer: string
        type: string
   

}