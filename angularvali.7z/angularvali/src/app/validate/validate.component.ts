import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Iuser } from './user';
import { Router } from '../../../node_modules/@angular/router';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-validate',
  templateUrl: './validate.component.html',
  styleUrls: ['./validate.component.css']
})
export class ValidateComponent implements OnInit {

  users: Iuser[];
  check: Iuser;
  id: string;
  name: string;
  username: string;
  password: string;
  type: string;
  var: boolean = false;
  merchant: string = "MERCHANT";
  customer: string = "customer";
  admin: string = "admin";

  constructor(private service: UserService, private router: Router) { }
  ngOnInit() {
    this.service.getAll().subscribe(data => this.users = data);

  }
  

  ValidateDetails() {
    var hasNumber = /\d/;
    console.log(hasNumber.test("AB"));
console.log(this.service.userList)
    if (this.id.includes("@") && this.id.includes(".")) {
      if(hasNumber.test(this.password)){
        let arr = this.users.filter(p => p.email == this.id && p.password==this.password);
      console.log(arr)
      console.log(this.users)
      console.log(this.id);
      console.log(this.password);
      if (arr.length > 0) {
        arr.map(p => this.check = p);
        console.log(this.check)
        if (this.check.type === this.admin) {
          this.router.navigate(['/admin']);
        }
        else if (this.check.type === this.customer) {
          this.router.navigate(['/cust']);
        }
        else if (this.check.type === this.merchant) {
          this.router.navigate(['/merchant']);
        }
      }
    }
    else{
      alert("Password Should Contain Only Numbers");
    }
  }
    else {
      alert("Enter Valid Email ID");
    }

  }

}
