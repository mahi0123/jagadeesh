package com.cg.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.MerchantRepository;
import com.cg.dao.ProductRepository;
import com.cg.model.Merchant;
import com.cg.model.Product;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ProductController {

	private final ProductRepository productRepository;

	public ProductController(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@GetMapping("/getProducts")
	public List<Product> getCouponns() {
		return (List<Product>) productRepository.findAll();
	}

	@PostMapping("/addProduct")
	void addUser(@RequestBody Product coupon) {
		productRepository.save(coupon);
	}

	@GetMapping(value = "/product/{id}")
	public Optional<Product> getProduct(@PathVariable Integer id) {
		return productRepository.findById(id);
	}

	/*
	 * private List<Coupon> Coupons = createList();
	 * 
	 * @RequestMapping(value = "/coupons", method = RequestMethod.GET, produces =
	 * "application/json") public List<Coupon> firstPage() { return Coupons; }
	 * 
	 * private static List<Coupon> createList() { List<Coupon> tempCoupons = new
	 * ArrayList<>(); Coupon coupon = new Coupon(); coupon.setCouponId(1);
	 * coupon.setCouponDate("2019-05-29"); coupon.setCouponValidity("2019-6-31");
	 * coupon.setCouponTitle("Flash Sale Coupon"); coupon.setCouponCode("flash10");
	 * coupon.setDiscountType("percentage"); coupon.setCouponDiscount(10);
	 * coupon.setCouponState(true);
	 * 
	 * Coupon coupon2 = new Coupon(); coupon2.setCouponId(2);
	 * coupon2.setCouponDate("2019-05-29"); coupon2.setCouponValidity("2019-6-31");
	 * coupon2.setCouponTitle("Flash Sale Coupon");
	 * coupon2.setDiscountType("percentage"); coupon2.setCouponCode("flash20");
	 * coupon2.setCouponDiscount(20); coupon2.setCouponState(true);
	 * 
	 * tempCoupons.add(coupon); tempCoupons.add(coupon2); return tempCoupons; }
	 */
}
