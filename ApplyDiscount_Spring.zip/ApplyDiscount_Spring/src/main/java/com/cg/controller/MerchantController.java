package com.cg.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cg.dao.MerchantRepository;
import com.cg.model.Merchant;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class MerchantController {

	private final MerchantRepository couponRepository;

	public MerchantController(MerchantRepository couponRepository) {
		this.couponRepository = couponRepository;
	}

	@GetMapping("/getMerchants")
	public List<Merchant> getMerchants() {
		return (List<Merchant>) couponRepository.findAll();
	}
	
	@PostMapping("/addMerchant")
    void addUser(@RequestBody Merchant coupon) {
        couponRepository.save(coupon);
    }
	
	@PutMapping("/merchants/{id}")
	public ResponseEntity<Merchant> updateEmployee(@RequestBody Merchant merchant, @PathVariable String id) {
		Merchant newMerchant = couponRepository.save(merchant);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(newMerchant.getmerchantId());
		return ResponseEntity.created(location).build();
	}
	/*
	 * private List<Coupon> Coupons = createList();
	 * 
	 * @RequestMapping(value = "/coupons", method = RequestMethod.GET, produces =
	 * "application/json") public List<Coupon> firstPage() { return Coupons; }
	 * 
	 * private static List<Coupon> createList() { List<Coupon> tempCoupons = new
	 * ArrayList<>(); Coupon coupon = new Coupon(); coupon.setCouponId(1);
	 * coupon.setCouponDate("2019-05-29"); coupon.setCouponValidity("2019-6-31");
	 * coupon.setCouponTitle("Flash Sale Coupon"); coupon.setCouponCode("flash10");
	 * coupon.setDiscountType("percentage"); coupon.setCouponDiscount(10);
	 * coupon.setCouponState(true);
	 * 
	 * Coupon coupon2 = new Coupon(); coupon2.setCouponId(2);
	 * coupon2.setCouponDate("2019-05-29"); coupon2.setCouponValidity("2019-6-31");
	 * coupon2.setCouponTitle("Flash Sale Coupon");
	 * coupon2.setDiscountType("percentage"); coupon2.setCouponCode("flash20");
	 * coupon2.setCouponDiscount(20); coupon2.setCouponState(true);
	 * 
	 * tempCoupons.add(coupon); tempCoupons.add(coupon2); return tempCoupons; }
	 */
}
