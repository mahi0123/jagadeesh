package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity(name = "merchant")
public class Merchant {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int merchantId;
	
	@Column
	private int productDiscount;
	
	public int getmerchantId() {
		return merchantId;
	}

	public void setmerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public int getProductDiscount() {
		return productDiscount;
	}

	public void setProductDiscount(int productDiscount) {
		this.productDiscount = productDiscount;
	}

	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", productDiscount=" + productDiscount + "]";
	}
}
