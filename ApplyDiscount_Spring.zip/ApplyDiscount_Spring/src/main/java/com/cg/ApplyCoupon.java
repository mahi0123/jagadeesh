package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplyCoupon {
	public static void main(String[] args) {
		SpringApplication.run(ApplyCoupon.class, args);
	}
}
