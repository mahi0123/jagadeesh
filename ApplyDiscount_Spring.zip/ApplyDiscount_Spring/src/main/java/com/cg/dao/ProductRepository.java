package com.cg.dao;

import org.springframework.data.repository.CrudRepository;
import com.cg.model.Merchant;
import com.cg.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{

}
