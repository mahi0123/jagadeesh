package com.cg.dao;

import org.springframework.data.repository.CrudRepository;
import com.cg.model.Merchant;

public interface MerchantRepository extends CrudRepository<Merchant, Integer>{

}
