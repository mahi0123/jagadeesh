package com.cg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ApplyDiscountPOM {
	WebDriver driver;

	@FindBy(how = How.XPATH, using = "/html/body/app-root/div/app-apply-discount/div[1]/select[1]")
	@CacheLookup
	private WebElement merchantId;


	@FindBy(how = How.XPATH, using = "/html/body/app-root/div/app-apply-discount/div[1]/select[2]")
	@CacheLookup
	private WebElement discountPercaentage;

	@FindBy(how = How.XPATH, using = "/html/body/app-root/div/app-apply-discount/div[1]/button")
	@CacheLookup
	private WebElement applyButton;

	@FindBy(how = How.XPATH, using = "/html/body/app-root/div/app-apply-discount/div[3]/table[1]/tbody/tr[2]/td[4]/button")
	@CacheLookup
	private WebElement addToCartButton;

	@FindBy(how = How.XPATH, using = "/html/body/app-root/div/app-apply-discount/div[3]/table[2]/tbody/tr[2]/td[2]")
	@CacheLookup
	private WebElement merchantTableDiscount;

	@FindBy(how = How.XPATH, using = "/html/body/app-root/div/app-apply-discount/div[3]/table[3]/tbody/tr[2]/td[3]")
	@CacheLookup
	private WebElement discountedPrice;

	public ApplyDiscountPOM() {
		super();
	}

	public ApplyDiscountPOM(WebDriver driver) {
		super();
		this.driver = driver;
	}


	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId.sendKeys(merchantId);
	}

	public WebElement getDiscountPercaentage() {
		return discountPercaentage;
	}

	public void setDiscountPercaentage(String discountPercaentage) {
		this.discountPercaentage.sendKeys(discountPercaentage);
	}

	public WebElement getApplyButton() {
		return applyButton;
	}

	public void clickApplyButton() {
		this.applyButton.click();
	}

	public WebElement getAddToCartButton() {
		return addToCartButton;
	}

	public void setAddToCartButton(WebElement addToCartButton) {
		this.addToCartButton.click();
	}

	public WebElement getMerchantTableDiscount() {
		return merchantTableDiscount;
	}

	public void setMerchantTableDiscount(WebElement merchantTableDiscount) {
		this.merchantTableDiscount = merchantTableDiscount;
	}

	public WebElement getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(WebElement discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
	
	

	/*public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public WebElement getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}*/

	/*public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender() {
		this.gender.click();
	}

	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language.sendKeys(language);
	}

	public WebElement getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description.sendKeys(description);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}*/
}
