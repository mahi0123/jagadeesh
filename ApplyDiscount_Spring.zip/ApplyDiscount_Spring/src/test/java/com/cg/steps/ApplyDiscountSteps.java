package com.cg.steps;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.pom.ApplyDiscountPOM;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;

public class ApplyDiscountSteps {
	WebDriver driver;
	ApplyDiscountPOM page;

	@Before
	public void setUp() {
		driver = BrowserFactory.startBrowser("chrome",
				"http://localhost:4200/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() {
		driver.close();
	}

	@Given("^User is on Apply Discount Form$")
	public void user_is_on_Apply_Discount_Form() throws Throwable {
		
		Thread.sleep(1000);
	}

	@Then("^Verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		assertEquals("DiscountPortable", driver.getTitle());
		if (driver.getTitle().equals("DiscountPortable")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@When("^User leaves merchantId empty$")
	public void user_leaves_merchantId_empty() throws Throwable {
		page.setDiscountPercaentage("10");
	}

	@Then("^Display merchnatId Alert msg$")
	public void display_merchnatId_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Select Discount percentage")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^User leaves Discount Percentage empty$")
	public void user_leaves_Discount_Percentage_empty() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Display Discount Percentage Alert msg$")
	public void display_Discount_Percentage_Alert_msg() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^Customer clicks the Apply button$")
	public void customer_clicks_the_Apply_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Update Merchant Table$")
	public void update_Merchant_Table() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^Customer clicks the Add To cart button$")
	public void customer_clicks_the_Add_To_cart_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Update Cart Table$")
	public void update_Cart_Table() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}
}
