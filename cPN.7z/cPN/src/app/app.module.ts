import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ApplyCouponComponent } from './apply-coupon/apply-coupon.component';
import { HttpClientModule } from '@angular/common/http';
import { CouponService } from './coupon.service';

@NgModule({
  declarations: [
    AppComponent,
    ApplyCouponComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [CouponService],
  bootstrap: [AppComponent]
})
export class AppModule { }
