import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Coupon } from './apply-coupon/Coupon';

@Injectable({
  providedIn: 'root'
})
export class CouponService {

  couponList:Coupon[];

  constructor(private http:HttpClient) {
  }

  getCouponsList() {
    //this.http.get<Coupon[]>("assets/Coupons.json").subscribe(data=> this.couponList = data);
    this.http.get<Coupon[]>('http://localhost:8090/coupons').subscribe(data=> this.couponList = data);
  }
}
