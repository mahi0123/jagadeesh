import { Component, OnInit } from '@angular/core';
import { CouponService } from '../coupon.service';
import { Coupon } from './Coupon';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-apply-coupon',
  templateUrl: './apply-coupon.component.html',
  styleUrls: ['./apply-coupon.component.css']
})
export class ApplyCouponComponent implements OnInit {

  constructor(private couponService: CouponService) { }
  couponTextBox: boolean;

  couponDiscounted: boolean;
  couponApplied: boolean;

  couponErrorApplied: boolean;
  couponMsg: string;
  couponErrMsg: string;
  couponCode: string;

  appliedCoupon: string;
  appliedDiscount: number;
  appliedDiscountMethod: string;

  dummyAmount = 50000;
  dummyAmountCopy = 50000;

  couponRedemptionCouunt: number;
  couponExpiryDate: Date;

  today: Date = new Date();

  ngOnInit() {
    this.couponService.getCouponsList();
  }

  showCouponTextBox(): any {
    this.couponTextBox = true;
  }

  validateDate() {
    if (this.couponExpiryDate.getFullYear() == this.today.getFullYear()) {
      if (this.couponExpiryDate.getMonth() > this.today.getMonth()) {
        return true;
      }
      else if (this.couponExpiryDate.getMonth() == this.today.getMonth()) {
        if (this.couponExpiryDate.getDate() >= this.today.getDate()) {
          return true;
        }
        else {
          return false;
        }
      }
      else
        return false;
    }
    else if (this.couponExpiryDate.getFullYear() > this.today.getFullYear()) {
      return true;
    }
    else
      return false;
  }

  applyCoupon() {
    console.log(this.couponService.couponList);
    if (this.couponCode != this.appliedCoupon) {
      this.couponDiscounted = false;
      this.dummyAmount = this.dummyAmountCopy;
    }

    for (let coupon of this.couponService.couponList) {
      if (coupon.couponCode == this.couponCode.toLowerCase()) {
        this.couponExpiryDate = new Date(coupon.couponValidity);
        if (coupon.couponState && this.validateDate() == true) {
          if (!this.couponApplied && this.couponErrorApplied && !this.couponDiscounted) {
            if (coupon.discountType == "percentage") {
              this.dummyAmount -= ((this.dummyAmount * coupon.couponDiscount) / 100);
              this.couponApplied = true;
              this.couponErrorApplied = false;
              this.couponDiscounted = true;
              this.appliedCoupon = coupon.couponCode;
              this.appliedDiscountMethod = coupon.discountType;
              this.appliedDiscount = coupon.couponDiscount;
              this.couponMsg = "Coupon Applied Succesfully!!!";
            }
            else if (coupon.discountType == "amount") {
              this.dummyAmount -= coupon.couponDiscount;
              this.couponApplied = true;
              this.couponErrorApplied = false;
              this.couponDiscounted = true;
              this.appliedCoupon = coupon.couponCode;
              this.appliedDiscountMethod = coupon.discountType;
              this.appliedDiscount = coupon.couponDiscount;
              this.couponMsg = "Coupon Applied Succesfully!!!";
            }
          }
          else
          {
            console.log(coupon);
            this.couponMsg = "Coupon Already Aplied!!!";
          }
        }
        else {
          this.couponMsg = "Coupon Expired!!!";
          this.couponApplied = false;
          this.couponErrorApplied = true;
        }
        break;
      }
      else {
        this.couponMsg = "Coupon Not Valid!!!";
        this.couponApplied = false;
        this.couponErrorApplied = true;
      }
    }
  }
}

