export interface Coupon{
    couponId:number;
    couponDate:string;
    couponValidity:string;
    couponTitle:string;
    couponCode:string;
    couponDiscount:number;
    discountType:string;
    couponState:boolean;
}