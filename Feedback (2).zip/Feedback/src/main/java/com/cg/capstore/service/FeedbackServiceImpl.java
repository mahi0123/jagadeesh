package com.cg.capstore.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.exception.*;
import com.cg.capstore.dao.IFeedbackDao;
import com.cg.capstore.entitites.Feedback;

@Service
@Transactional
public class FeedbackServiceImpl implements IFeedbackService {
	
	@Autowired IFeedbackDao dao;

	@Transactional
	public void addFeedback(Feedback fb) {
		// TODO Auto-generated method stub
		 {
//			 if(cmob==fb.getCmob())
		dao.save(fb);
		}
		
	}

	@Transactional
	public List<Feedback> getAllFeedbacks() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Transactional
	public Feedback findbypname(String pname) throws ApplicationException {
		// TODO Auto-generated method stub
		Optional<Feedback> fb= dao.findById(pname);
		if(!fb.isPresent())
		{
			throw new ApplicationException("Product not found");
		}
		
		return dao.findById(pname).get();
	}

}
