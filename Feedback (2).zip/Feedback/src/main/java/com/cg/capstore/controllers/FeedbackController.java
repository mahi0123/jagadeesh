package com.cg.capstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entitites.Feedback;
import com.cg.capstore.service.FeedbackServiceImpl;

@RestController
@RequestMapping("/feedback")
public class FeedbackController {

	@Autowired FeedbackServiceImpl service;
	
	@PostMapping(value= {"/add"}, consumes= {"application/json", "application/xml"})
	public ResponseEntity<String> addFeedback(@RequestBody Feedback fb)
	{
		service.addFeedback(fb);
		return new ResponseEntity<String>("Feedback Added Succesfully!!" +fb.toString(), HttpStatus.CREATED);
		
	}
	
	@GetMapping(value="{pname}"  ,produces= {"application/json", "application/xml"})
	public Feedback findByPname(@PathVariable String pname)
	{
		System.out.println("Feedbackfound" +pname);
		return service.findbypname(pname);
		
	}
	
	@GetMapping(value="/getall"  ,produces= {"application/json", "application/xml"})
	public List<Feedback> getall() {
		
		return service.getAllFeedbacks();
	}
}
