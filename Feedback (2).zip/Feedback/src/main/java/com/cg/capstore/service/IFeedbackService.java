package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entitites.Feedback;

public interface IFeedbackService {

	
	public void addFeedback(Feedback fb);
	List<Feedback>getAllFeedbacks();
	Feedback findbypname(String pname);
}
