/*package com.cg.capstore.entitites;

public class Feedback {

}
*/
package com.cg.capstore. entitites;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name="feedbacks")
public class Feedback implements Serializable{
	
	
	@Id
	@Column(name="cmob", length=20)
	private String cmob;
	@Column(name="feedbackid", length=20)
//	@GeneratedValue(strategy= GenerationType.AUTO)
	private String feedbackId;
	
	
	
	
	@Column(name="productname", length=20)
	private String productName;
	
	@Column(name="reviews", length=50)
	private String reviews;
	
	

	

	

	

	

	public String getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getCmob() {
		return cmob;
	}

	public void setCmob(String cmob) {
		this.cmob = cmob;
	}

	

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getReviews() {
		return reviews;
	}

	public void setReviews(String reviews) {
		this.reviews = reviews;
	}
	
	

	public Feedback() {
		super();
	}

	public Feedback(String feedbackId, String cmob, String productName, String reviews) {
		super();
		this.feedbackId = feedbackId;
		this.cmob = cmob;
		this.productName = productName;
		this.reviews = reviews;
	}

	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", cmob=" + cmob + ", productName=" + productName + ", reviews="
				+ reviews + "]";
	}

	
	
	

}
