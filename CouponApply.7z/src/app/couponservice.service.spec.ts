import { TestBed } from '@angular/core/testing';

import { CouponserviceService } from './couponservice.service';

describe('CouponserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CouponserviceService = TestBed.get(CouponserviceService);
    expect(service).toBeTruthy();
  });
});
