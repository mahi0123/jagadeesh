export interface Coupon
/* {
    couponId:number;
    couponDate:string;
    couponValidity:string;
    couponRedemptionCount:number;
    couponTitle:string;
    couponCode:string;
    couponDiscount:number;
    discountType:string;
    couponCategory:string;
    couponState:boolean;
}, */

{
    couponid: number;
    couponcode: string;
    fromDate:string;
    toDate: string,
    status: string;
    startprice: number;
    endprice: number;
    discount: number;
}