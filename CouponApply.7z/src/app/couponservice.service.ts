import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Coupon } from './coupon/Coupon';


@Injectable({
  providedIn: 'root'
})
export class CouponserviceService {
url:string='http://localhost:8081/users'
urljson:string='assets/Coupons.json'
  coupons:Coupon[];
  constructor(private http:HttpClient) { }

  getcoupons()
  {
    this.http.get<Coupon[]>(this.url).subscribe(data=>this.coupons = data);
  }
}
/* assets/Coupons.json */