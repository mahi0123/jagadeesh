import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { User } from '../model/rating.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

    //
  constructor(private http:HttpClient) { }
  
  baseUrl:string ='http://localhost:8090/api/v1';
  //http://localhost:8090/api/v1/getProductRating/1011
  //get users
  getRating(mob:number){
    return this.http.get<User>(this.baseUrl+'/getProductRating/'+mob);
  }
  //get user byId
  getUserbyId(id:number){
    return this.http.get<User>(this.baseUrl+'/'+id);
  }
  //Create all users
  createUser(user:User){
    return this.http.post(this.baseUrl,user);
}
//modify user
// updateUser(user:User){
//   return this.http.put(this.baseUrl+'/'+user.id,user);

// }
//Delete user
deleteUser(id:number){
  return this.http.delete(this.baseUrl+'/'+id)

}
  
}

