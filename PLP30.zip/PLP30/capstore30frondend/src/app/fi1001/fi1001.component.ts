import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '../../../node_modules/@angular/router';
import { UserService } from '../service/user.service';
import { User } from '../model/rating.model';
@Component({
  selector: 'app-fi1001',
  templateUrl: './fi1001.component.html',
  styleUrls: ['./fi1001.component.css']
})
export class Fi1001Component implements OnInit {
  users:User;
  constructor(private router:Router,private userService:UserService) { }

  ngOnInit() {
    this.userService.getRating(1011)

    .subscribe(data=>{ 
      //subscribe method observes all the changes and update teh changes
  
    //this.products = this.products.filter(u=> u!==product);
  
    this.users=data
  
     });
  }

}
