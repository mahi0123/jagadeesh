export class User{
    feedbackid:string;
    ratingproduct:number;
    ratingmerchant:number;
    comment:string;
    productId:number;
    customerId:number;
    merchantId:number
    
    }