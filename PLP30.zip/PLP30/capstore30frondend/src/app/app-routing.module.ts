import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RatingComponent } from './rating/rating.component';
import { Fi1001Component } from './fi1001/fi1001.component';
import { Fi1002Component } from './fi1002/fi1002.component';

const routes: Routes = [
  // {path:'login',component:LoginComponent},
  {path:'rating',component:RatingComponent},
  {path:'fi1011',component:Fi1001Component},
   {path:'fi1012',component:Fi1002Component},
  // {path:'edit-user',component:EditUserComponent},
  // {path:'edit-user/:id',component:EditUserComponent},
  // {path:'',component: HomeComponent},
  //or
  //{path:'',redirectTo:'/home',pathMatch:'full'},
  // {path:'**',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
