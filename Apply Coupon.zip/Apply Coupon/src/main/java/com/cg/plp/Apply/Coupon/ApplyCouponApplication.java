package com.cg.plp.Apply.Coupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplyCouponApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplyCouponApplication.class, args);
	}

}
