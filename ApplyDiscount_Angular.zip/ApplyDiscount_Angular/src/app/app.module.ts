import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ApplyDiscountComponent } from './apply-discount/apply-discount.component';
import { HttpClientModule } from '@angular/common/http';
import { DiscountService } from './discount.service';

@NgModule({
  declarations: [
    AppComponent,
    ApplyDiscountComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule 
  ],
  providers: [DiscountService],
  bootstrap: [AppComponent]
})
export class AppModule { }
