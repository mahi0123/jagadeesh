import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Merchant } from './apply-discount/Merchant';
import { Product } from './apply-discount/Product';

@Injectable({
  providedIn: 'root'
})
export class DiscountService {

  merchantList: Merchant[];
  productList: Product[];

  constructor(private http: HttpClient, private http2:HttpClient) { }

  getMerchantList() {
    this.http.get<Merchant[]>("http://localhost:8090/getMerchants").subscribe(data => this.merchantList = data);
    this.http2.get<Product[]>('http://localhost:8090/getProducts').subscribe(data => this.productList = data);
    console.log(this.productList);
  }

  applyDiscountPercentage(id:number,merchant:Merchant){
    this.http.put<Merchant>('http://localhost:8090/merchants/'+id, merchant).subscribe();
  }
}
