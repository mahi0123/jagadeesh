export interface Cart{
    merchantId:number,
    productPrice:number,
    discountedPrice:number;
}