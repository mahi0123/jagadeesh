export interface Product{
    productId:number,
    merchantId:number,
    productPrice:number;
}
