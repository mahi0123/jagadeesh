import { Component, OnInit } from '@angular/core';
import { DiscountService } from '../discount.service';
import { Merchant } from './Merchant';
import { Cart } from './Cart';

@Component({
  selector: 'app-apply-discount',
  templateUrl: './apply-discount.component.html',
  styleUrls: ['./apply-discount.component.css']
})
export class ApplyDiscountComponent implements OnInit {

  constructor(private discountService: DiscountService) { }

  discountRange: number[] = [];

  cartList: Cart[] = [];
  merchantList: Merchant[] = [];

  merchantId: number;
  discountPercentage: number;


  ngOnInit() {
    this.discountService.getMerchantList();
    for (let i = 0; i <= 100; i++) {
      this.discountRange.push(i);
    }
    console.log(this.discountRange);
  }

  applyDiscount() {
    console.log(this.discountService.merchantList);

    if (this.merchantId != undefined && this.discountPercentage != undefined) {
      console.log(this.merchantList);
      const merchant = <Merchant>({
        merchantId: this.merchantId,
        productDiscount: this.discountPercentage
      });
      this.discountService.applyDiscountPercentage(merchant.merchantId, merchant);
      location.reload();
    }

    else {
      alert("Select Discount percentage");
    }
  }

  addToCart(product: any) {
    if (this.discountService.merchantList.length == 0) {
      alert("Discount Detials Not Found");
    }
    let discountPresent = true;

    for (let merchant of this.discountService.merchantList) {
      if (product.merchantId == merchant.merchantId) {
        const cart = <Cart>({
          merchantId: product.merchantId,
          productPrice: product.productPrice,
          discountedPrice: (product.productPrice - (product.productPrice * merchant.productDiscount) / 100)
        });
        this.cartList.push(cart);
        discountPresent = true;
      }
      else {
        discountPresent = false;
      }
    }
  }
}
