export interface Merchant{
    merchantId: number;
    productDiscount: number;
}