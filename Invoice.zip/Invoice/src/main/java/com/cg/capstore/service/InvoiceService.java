package com.cg.capstore.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.Order;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.IInvoiceDao;
import com.cg.capstore.model.Invoice;


@Service("invoiceService")
@Transactional
public class InvoiceService  implements IInvoiceService{

	@Autowired
	IInvoiceDao invoiceDao;
	
	@Autowired
	IInvoiceService orderService;
	
	@Transactional
	public Invoice getInvoiceFromOrderId(int OrderId) {
		
		Invoice myOrder = orderService.findOrderById(OrderId);
		
		List<Invoice> invoices=invoiceDao.findAll();;
		
		for(Invoice myInvoice: invoices) {
			if(myInvoice.getOrderId().equals(myOrder)) {
				return myInvoice;
			}
		}
		return null;
	}

@Transactional
	public boolean generateInvoice(Invoice invoice) {
		
		invoiceDao.save(invoice);
		
		return true;
	}

@Transactional
	public List<Invoice> getInvoiceDetailsBetweenDates(Date fromDate, Date toDate) {
		List<Invoice> invoiceDetails=invoiceDao.getInvoiceDetailsBetweenDates(fromDate, toDate);
		return invoiceDetails;
	}

@Transactional
	public Invoice findAll() {
		// TODO Auto-generated method stub
		return orderService.findAll();
	}

	@Transactional
	public Invoice findOrderById(int orderId) {
		// TODO Auto-generated method stub
		System.out.println("Finding employee: " + orderId);
		Optional<Invoice> temp = invoiceDao.findById(orderId);
		if (!temp.isPresent()) {
		System.out.println("Record Not Found....!");
		}
		return temp.get();
	}
}