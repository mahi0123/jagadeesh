package com.cg.capstore.service;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.Order;

import com.cg.capstore.model.Invoice;


public interface IInvoiceService {
	
	public Invoice getInvoiceFromOrderId(int OrderId);
         public boolean generateInvoice(Invoice invoice);
     
         public Invoice findAll();

	public List<Invoice> getInvoiceDetailsBetweenDates(Date fromDate, Date toDate);
	public Invoice findOrderById(int orderId);
       



}