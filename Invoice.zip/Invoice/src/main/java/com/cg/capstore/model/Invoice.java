package com.cg.capstore.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Order;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="invoice")
@XmlRootElement
public class Invoice  {
	
	@Id
	@Column(name="invoiceNo")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int invoiceNo;
	
	
	//@OneToOne(targetEntity=Order.class)
	@Column(name="oid")
	private Order orderId;
	
	@JsonFormat(pattern="dd-MM-yyyy")
	@Column(name="starttime")
	private Date InvoiceDate;
	@Column(name="quantity")
	private double discountedPrice;
	@Column(name="amount")
	private double discount;
	
	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Invoice(int invoiceNo, Order orderId, Date invoiceDate, double discountedPrice, double discount) {
		super();
		this.invoiceNo = invoiceNo;
		this.orderId = orderId;
		InvoiceDate = invoiceDate;
		this.discountedPrice = discountedPrice;
		this.discount = discount;
	}

	public int getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(int invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Order getOrderId() {
		return orderId;
	}

	public void setOrderId(Order orderId) {
		this.orderId = orderId;
	}

	public Date getInvoiceDate() {
		return InvoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		InvoiceDate = invoiceDate;
	}

	public double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	
}