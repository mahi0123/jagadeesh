package com.cg.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.model.Category;
import com.cg.model.Product;

public interface CategoryRepository extends JpaRepository<Category, Integer>{
	/*@Query("select product from Product product")
	List<Product> displayListOfProducts();*/
}