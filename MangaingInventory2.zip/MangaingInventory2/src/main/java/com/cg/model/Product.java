package com.cg.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "Products")

@XmlRootElement
public class Product 
{
  @Id
 // @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "pid", length = 20)
  private int pid;
 
  //Date startTime;
	
  //Date endTime;
  @Column(name = "pname", length = 20)
 private String pname;
  
  //String description;
  @Column(name = "cost", length = 20)
  private float cost;
  
  //String status;
  
  //int quantity;
  
  //String imageUrl;
  @Column(name = "viewCount", length = 20)
  private int viewCount;
  
  /*@OneToOne()
  Merchant merchant;
  
  @OneToOne()
  Discount discount;*/
  
  /*@ManyToOne
  @JoinColumn(name="cid")
  Category category;
  
  //@OneToMany(cascade=CascadeType.ALL , targetEntity=FeedBack.class)
  //List feedback;*/

public int getId() {
	return pid;
}

public void setId(int pid) {
	this.pid = pid;
}

/*public Date getStartTime() {
	return startTime;
}

public void setStartTime(Date startTime) {
	this.startTime = startTime;
}

public Date getEndTime() {
	return endTime;
}

public void setEndTime(Date endTime) {
	this.endTime = endTime;
}*/

public String getName() {
	return pname;
}

public void setName(String pname) {
	this.pname = pname;
}

/*public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}
*/
public float getCost() {
	return cost;
}

public void setCost(float cost) {
	this.cost = cost;
}

/*public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}

public String getImageUrl() {
	return imageUrl;
}

public void setImageUrl(String imageUrl) {
	this.imageUrl = imageUrl;
}*/

public int getViewCount() {
	return viewCount;
}

public void setViewCount(int viewCount) {
	this.viewCount = viewCount;
}

/*public Merchant getMerchant() {
	return merchant;
}

public void setMerchant(Merchant merchant) {
	this.merchant = merchant;
}

public Discount getDiscount() {
	return discount;
}

public void setDiscount(Discount discount) {
	this.discount = discount;
}
*/
/*public Category getCategory() {
	return category;
}

public void setCategory(Category category) {
	this.category = category;
}

public List getFeedback() {
	return feedback;
}

public void setFeedback(List feedback) {
	this.feedback = feedback;
}*/

public Product(int pid,  String pname, float cost, 
	  int viewCounty
		) {
	super();
	this.pid = pid;
	//this.startTime = startTime;
	//this.endTime = endTime;
	this.pname = pname;
	//this.description = description;
	this.cost = cost;
	//this.status = status;
	//this.quantity = quantity;
	//this.imageUrl = imageUrl;
	this.viewCount = viewCount;
	//this.merchant = merchant;
	//this.discount = discount;
	//this.category = category;
	//this.feedback = feedback;
}

public Product() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Product [pid=" + pid + ",  pname=" + pname
			 + ", cost=" + cost  
			+  ", viewCount=" + viewCount +  
			  "]";
}
  
  
}