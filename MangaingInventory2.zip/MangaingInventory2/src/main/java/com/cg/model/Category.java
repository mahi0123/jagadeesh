package com.cg.model;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "InventorY")

@XmlRootElement
public class Category implements Serializable
{
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "cid", length = 20)
	private int cid;
	/*@Column(name = "startTime", length = 20)
	private Date startTime;
	@Column(name = "endTime", length = 20)
	private Date endTime;*/
	@Column(name = "cname", length = 20)
	private String cname;
	
@OneToMany(mappedBy="Product")
	public int getId() {
		return cid;
	}
	public void setId(int cid) {
		this.cid = cid;
	}

	/*public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = Date.valueOf(LocalDate.now());
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}*/

	public String getName() {
		return cname;
	}

	public void setName(String cname) {
		this.cname = cname;
	}

	@Override
	public String toString() {
		return "Category [cid=" + cid +  ", cname=" + cname + "]";
	}

	public Category(int id, String name) {
		super();
		this.cid = cid;
		//this.startTime = startTime;
		//this.endTime = endTime;
		this.cname = cname;
	}

	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}