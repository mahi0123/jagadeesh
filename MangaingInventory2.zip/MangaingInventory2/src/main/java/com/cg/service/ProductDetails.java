package com.cg.service;

import com.cg.model.Product;

public interface ProductDetails {

	public Product getProductDetails();
}